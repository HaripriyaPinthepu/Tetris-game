
/* JavaScript content from js/jsTetris.js in folder common */
/**
 * 
 */